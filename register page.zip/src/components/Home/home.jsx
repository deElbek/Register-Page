function Home() {
    return ( 
        <>
         <h1 style={{textAlign:"center"}}>Hello There!</h1>
        </>
     );
}

export default Home;